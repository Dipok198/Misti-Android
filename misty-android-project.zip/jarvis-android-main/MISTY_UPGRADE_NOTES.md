# Misty upgrade notes

This project has been rebranded from JARVIS to Misty in the Android app label and
assistant prompt. The conversational prompt now supports affectionate, playful,
girlfriend-like role-play while remaining transparent that Misty is an AI and does
not literally experience emotions.

## Important capabilities and limits

1. **Wake phrase:** the existing ONNX model file is `hey_jarvis_v0.1.onnx` and was
   trained for “Hey Jarvis”. It has not been replaced with a “Hey Misty” model.
   The Settings screen deliberately continues to report the actual model phrase.
   Do not simply change the phrase constant: that would only change the label and
   would not make the acoustic model recognise “Hey Misty”.
2. **Voice profile:** the existing five-sample voice profile can act as an extra
   speaker-matching gate for wake detection. It is not liveness detection and is
   vulnerable to replay/voice cloning; do not use it to unlock Android.
3. **Lock screen:** Android's secure keyguard cannot be dismissed by an ordinary
   third-party app based only on a custom voice phrase. The app currently ignores
   wake events while the phone is locked. Keep Android PIN/password/biometrics as
   the device authentication method.
4. **Phone control:** existing local tools, accessibility service and intents provide
   selected music, app, screen, contacts, calls and message workflows. They do not
   grant unrestricted A-to-Z control. Accessibility, contacts, microphone and
   notification permissions must be explicitly enabled, and high-impact actions
   retain confirmation.
5. **Rename:** the app label and compiled assistant name are currently set to Misty.
   A user-editable wake phrase and live rename UI are not implemented by this change.

## Build and test

Run `./gradlew :app:testDebugUnitTest` and `./gradlew :app:assembleDebug` in an
Android SDK/JDK 17 environment. The archive does not contain a signed release key.
